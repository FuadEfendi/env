#!/bin/bash

# Copyright (c) 2015,2018 Oracle and/or its affiliates. All rights reserved.
# For exporting a WebLogic domain to an archive for migration/importing to a partition
#

if [ $# -lt 2 ] ; then
   echo "Usage: exportDomainForPartition.sh {ORACLE_HOME} {WL_DOMAIN_HOME} [{KEYFILE}] [{TOOL_JAR}] [{APP_NAMES}] [{INCLUDE_APP_BITS}] [{WL_HOME}]"
   echo "where:"
   echo "   {ORACLE_HOME} : the MW_HOME of where the WebLogic is installed"
   echo "   {WL_DOMAIN_HOME} : the source WebLogic domain path"
   echo "   {KEYFILE} : an optional user-provided file containing a clear-text passphrase used to encrypt exported attributes written to the archive, default: None;"
   echo "   {TOOL_JAR} : file path to the com.oracle.weblogic.management.tools.migration.jar file. Optional if jar is in the same directory location as the exportDomainForPartition.sh"
   echo "   {APP_NAMES} : applicationNames is an optional list of application names to export. E.q:  [\'myapp1\',\'myapp2\']. By default, all applications in the domain are exported."
   echo "   {INCLUDE_APP_BITS} : an optional flag to indicate whether application binaries are included in archive. Defaults is 'true'."
   echo "  {WL_HOME} : an optional parameter giving the path of the weblogic server for version 10.3.6.Used only when the WebLogic Server from 10.3.6 release is installed under a directory other than {ORACLE_HOME}/wlserver_10.3"
   echo "  "
   echo " Example 1:"
   echo "   exportDomainForPartition.sh /Oracle_Home /Oracle_Home/user_projects/domains/base_domain "
   echo " Example 2:"
   echo "   exportDomainForPartition.sh /Oracle_Home /Oracle_Home/user_projects/domains/base_domain /usr/myUserKeyFile "
   echo " Example 3: Specifies the location of the com.oracle.weblogic.management.tools.migration.jar file "
   echo "   exportDomainForPartition.sh /Oracle_Home /Oracle_Home/user_projects/domains/base_domain /usr/myUserKeyFile /download/com.oracle.weblogic.management.tools.migration.jar "
   echo " Example 4: Only archives the 'myapp1' and 'myapp2' applications, and None for KeyFile "
   echo "   exportDomainForPartition.sh /Oracle_Home /Oracle_Home/user_projects/domains/base_domain None com.oracle.weblogic.management.tools.migration.jar [\'myapp1\',\'myapp2\'] true "

   exit 1
fi

ORACLE_HOME=$1
WL_DOMAIN_HOME=$2
KEYFILE=None
TOOL_JAR=`pwd`/com.oracle.weblogic.management.tools.migration.jar
BINHOME=.
APP_NAMES=None
INCLUDE_APP_BITS=None
TEMP_ORA_HOME=${ORACLE_HOME}
WL_HOME=None
MW_HOME=None
IMPLEMENTATION_VERSION=12.2.1.4
EQUALSET=0
for arg in $* ; do 
   hasE=`echo $arg | grep "=" | wc -l`
   if [ $hasE -eq 1 ] ; then
      EQUALSET=1 
      export $arg   
      echo $arg
   fi
done

if [ ! -e $WL_DOMAIN_HOME ] ; then
    echo "The WebLogic domain path does not exist!"
    echo "Please provide a proper WebLogic domain path."
    exit 1
fi

if [ -e $ORACLE_HOME/oracle_common/common/bin/wlst.sh ] ; then
   BINHOME=$ORACLE_HOME/oracle_common/common/bin
fi

if [ $EQUALSET -eq 0 ] ; then 
 if [ $# -ge 3 ] ; then
   if [ "None" != "$3" ] ; then
      KEYFILE=\"$3\"
   fi
 fi

 if [ $# -ge 4 ] ; then
  if [ "None" != "$4" ] ; then
   TOOL_JAR=$4
  fi
 fi

 if [ $# -ge 5 ] ; then
   if [ "None" != "$5" ] ; then
      APP_NAMES=\"$5\"
   fi 
 fi

 if [ $# -ge 6 ] ; then
   INCLUDE_APP_BITS=$6
 fi
 if [ $# -ge 7 ] ; then
   WL_HOME=$7
 fi
fi

if [ "." == "${BINHOME}" ] ; then
   if [ -e $ORACLE_HOME/wlserver_10.3/common/bin/wlst.sh ] ; then
      BINHOME=$ORACLE_HOME/wlserver_10.3/common/bin
   elif [ "None" != "${WL_HOME}" ] ; then
      BINHOME=${WL_HOME}/common/bin
	  MW_HOME=${ORACLE_HOME}
   else
      echo "The Oracle home WLST bin path is not found" 
   fi
   export JAVA_VENDOR="Oracle"
   if [ -z "${JAVA_HOME}" ] ; then
      echo " "
      echo "Please note: the classes in com.oracle.weblogic.management.tools.migration.jar are built with JDK8 and must be run with JDK8.  Set your JAVA_HOME to a JDK8 installation before running the export script."
      echo " "
   fi
fi

if [ "." == "${BINHOME}" ] ; then
    echo "The Oracle home WLST bin path is not found at "${ORACLE_HOME}
    echo "Please assure to run this export at the AdminServer."
    exit 1
fi

if [ "com.oracle.weblogic.management.tools.migration.jar" == $TOOL_JAR ] ; then
   TOOL_JAR=`pwd`/com.oracle.weblogic.management.tools.migration.jar
fi

if [ ! -e $TOOL_JAR ] ; then
   echo "Could not locate com.oracle.weblogic.management.tools.migration.jar file!"
   echo "Usage: exportDomainForPartition.sh {ORACLE_HOME} {WL_DOMAIN_HOME} [{KEYFILE}] [{TOOL_JAR}] [{APP_NAMES}] [{INCLUDE_APP_BITS}] [{WL_HOME}]"
   exit 1
fi

if [ -e outDir ] ; then
   rm -rf outDir
fi
mkdir outDir

if [ -e tmpwlst ] ; then
   rm -rf tmpwlst
fi
mkdir tmpwlst

if [ -e lifttmp ] ; then
   rm -rf lifttmp
fi
mkdir lifttmp

cd lifttmp
jar -xf $TOOL_JAR
cd ..
cp lifttmp/wlstScriptDir/*.py  tmpwlst/.
rm -rf lifttmp

echo "print \"WLST homepath:\"" >> runExport.py
echo "print System.getProperty(\"weblogic.wlstHome\") " >> runExport.py
echo "print sys.path" >> runExport.py
echo "exportForMigration('./outDir', '${WL_DOMAIN_HOME}', ${INCLUDE_APP_BITS}, ${KEYFILE}, ${APP_NAMES}, '${IMPLEMENTATION_VERSION}' ) " >> runExport.py
echo "exit() " >> runExport.py
EXT_PRE_CLASSPATH="${TOOL_JAR}${CLASSPATHSEP}${EXT_PRE_CLASSPATH}"
export EXT_PRE_CLASSPATH
WLST_EXT_CLASSPATH="${TOOL_JAR}${CLASSPATHSEP}${WLST_EXT_CLASSPATH}"
export WLST_EXT_CLASSPATH
PRE_CLASSPATH=${PRE_CLASSPATH}${CLASSPATHSEP}${TEMP_ORA_HOME}/modules/jettison_1.0.0.0_1-1.jar
export PRE_CLASSPATH
export WLST_HOME="`pwd`/tmpwlst"
export MW_HOME
${BINHOME}/wlst.sh runExport.py>`pwd`/outDir/exportDomain.out


rm -rf tmpwlst
rm runExport.py

echo "Export Weblogic domain completed to outDir."
ls -l ./outDir
echo "Please check the exportDomain.out file in the directory outDir for any errors/warnings reported during export, before proceeding further."
