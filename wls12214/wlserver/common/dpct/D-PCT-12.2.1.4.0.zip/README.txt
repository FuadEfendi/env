README - Domain to Partition Conversion Tool (D-PCT)
For WebLogic Server Domain Application Migration to Partition

Copyright (c) 2015, 2016, Oracle and/or its affiliates. All rights reserved.


Table of Contents
------------------
1. Overview
2. What is included in this zip file
3. How to export WebLogic domain applications
4. Using the JSON file to override defaults during import
5. How to import a domain archive to a WebLogic 12.2.1 (or later) Partition
6. Limitations

1. Overview
-----------
WebLogic Server 12.2.1 provides new multitenancy features that support running multiple independent partitions within a WLS domain. Partitions provide isolation of applications, resources, security, etc. from other partitions in the same domain.

The "Domain to Partition Conversion Tool" (D-PCT) provides users the ability to migrate their domain application environment from a previous release of WebLogic Server to a WLS 12.2.1 or later partition. Administrators may use the tool to setup and configure Partition Resource Groups, 
Resource Group Templates, and other artifacts. By default this tool attempts to move all application artifacts to the new partition, but also provides a mechanism for selectively moving individual application(s), libraries, and resources. 

Note that the cluster and server configurations of a domain are not applicable to a partition and therefore not mapped to the new 12.2.1 or later partition.

This migration is supported by two Domain-to-Partition tools:
* An export tool which copies the domain application environment of a pre-12.2.1 WebLogic Server into a portable "domain archive". 
  The export tool is contained in this zipfile. It can be used to export domains from the following releases: WLS 10.3.6, WLS 12.1.1, WLS 12.1.2, and WLS 12.1.3.
* An import tool, which creates a WebLogic domain partition from the domain archive created by the export tool.

For example, to move a domain environment from a WLS 12.1.3 installation to a WLS 12.2.1 partition:
(a) Copy this export tool to the host where WebLogic Server 12.1.3 is installed,
(b) Run the export tool on your source WLS 12.1.3 domain, creating a domain archive, [Section 3, below]
(c) On your target WLS 12.2.1 installation, configure any artifacts (e.g. virtual targets, security realms, etc.) that will be required for the new partition,
(d) Run the import tool on your target WLS 12.2.1 installation to create a new partition from the domain archive created, [Section 5, below]

The Domain to Partition Conversion Tool is available under {ORACLE_HOME}/wlserver/common/dpct. To avoid compatibility issues with the tool provided by the 
previous release(s) of WebLogic, it is recommended to obtain the tool from the WebLogic 12.2.1 installation where the domain archive will be imported to create the partition.

After a successful import of the domain archive, a restart of the domain is required by starting the partition to have a fully-functional and runnable WLS 12.2.1 partition.

2. What is included in this zip file
-----------------------------------------
There are six files in this D-PCT.zip
 . README.txt
      which is this file
 . exportDomainForPartition.sh
      a Linux script to run from the source WebLogic domain Admin Server host to export domain applications
 . export-domain.sh
      an alternate Linux script to run from the source WebLogic domain Admin Server host to export domain applications, which accepts inputs as name-value pairs.
 . exportDomainForPartition.cmd
      a Windows script to run from the source WebLogic domain Admin Server host to export domain applications
 . export-domain.cmd
      an alternate Windows script to run from the source WebLogic domain Admin Server host to export domain applications, which accepts inputs as name-value pairs.
 . com.oracle.weblogic.management.tools.migration.jar
      a jar file which contains the python scripts and java classes for exporting the source domain. This jar also generates a report indicating the applications 
      and resources which are exported as well as the resources which are skipped due to an unsupported configuration in a partitioned environment


3. How to export WebLogic domain applications
----------------------------------------------
a) Run the script exportDomainForPartition.sh/cmd on the host where the source WebLogic domain AdminServer resides.

Command usage:
  exportDomainForPartition.sh {ORACLE_HOME} {WL_DOMAIN_HOME} [{KEYFILE}] [{TOOL_JAR}] [{APP_NAMES}] [{INCLUDE_APP_BITS}] [{WL_HOME}]

  where:
      {ORACLE_HOME} : the MW_HOME of where the WebLogic is installed
      {WL_DOMAIN_HOME} : the source WebLogic domain path
      {KEYFILE} : an optional user-provided file containing a clear-text passphrase used to encrypt exported attributes written to the archive, default: None;
      {TOOL_JAR} : file path to the com.oracle.weblogic.management.tools.migration.jar file. Optional if jar is in the same directory location as the exportDomainForPartition.sh
      {APP_NAMES} : applicationNames is an optional list of application names to export. E.q:  [\'myapp1\',\'myapp2\']. By default, all applications in the domain are exported.
      {INCLUDE_APP_BITS} : an optional flag to indicate whether application binaries are included in archive. Defaults is 'true'.
      {WL_HOME} : an optional parameter giving the path of the weblogic server for version 10.3.6.Used only when the WebLogic Server from 10.3.6 release is installed under a 
                  directory other than {ORACLE_HOME}/wlserver_10.3
    
  Example 1:
    exportDomainForPartition.sh /Oracle_Home /Oracle_Home/user_projects/domains/base_domain
  Example 2:
    exportDomainForPartition.sh /Oracle_Home /Oracle_Home/user_projects/domains/base_domain /usr/myUserKeyFile
  Example 3: Specifies the location of the com.oracle.weblogic.management.tools.migration.jar file
    exportDomainForPartition.sh /Oracle_Home /Oracle_Home/user_projects/domains/base_domain /usr/myUserKeyFile /download/com.oracle.weblogic.management.tools.migration.jar
  Example 4: Only archives the 'myapp1' and 'myapp2' applications, and None for KeyFile
    exportDomainForPartition.sh /Oracle_Home /Oracle_Home/user_projects/domains/base_domain None com.oracle.weblogic.management.tools.migration.jar [\'myapp1\',\'myapp2\'] true

  Please note: the classes in com.oracle.weblogic.management.tools.migration.jar are built with JDK8 and must be run with JDK8. Set your JAVA_HOME to a JDK8 installation before running the export script.

  For example,
      bash-3.2$  export JAVA_HOME=/opt/jdk1.8.0
      bash-3.2$  ./exportDomainForPartition.sh /usr/mwhome1036  /usr/mwhome1036/user_projects/domains/base_domain keyFile com.oracle.weblogic.management.tools.migration.jar


  The domain archive output of the exportDomainForPartition is written to a new sub-directory: "outDir".
  For example,
      outDir/base_domain.zip
      outDir/base_domain-attributes.json
      outDir/base_domain-ExportLogReport.html
      outDir/exportDomain.out

Command usage in Windows:

       C:\> set JAVA_HOME=C:\jdk1.8.0 
       C:\> exportDomainForPartition.cmd

Usage: exportDomainForPartition.cmd {ORACLE_HOME} {WL_DOMAIN_HOME} [{KEYFILE}] [
{TOOL_JAR}] [{APP_NAMES}] [{INCLUDE_APP_BITS}] [{WL_HOME}]
where:
   {ORACLE_HOME} : the MW_HOME of where the WebLogic is installed
   {WL_DOMAIN_HOME} : the source WebLogic domain path
   {KEYFILE} : an optional user-provided file containing a clear-text passphrase used to encrypt exported attributes written to the archive, default: None;
   {TOOL_JAR} : file path to the com.oracle.weblogic.management.tools.migration.jar file. Optional if jar is in the same directory location as the exportDomainForPartition.sh
   {APP_NAMES} : applicationNames is an optional list of application names to export. E.q:  [app1+app2+app3]. By default, all applications in the domain are exported.
   {INCLUDE_APP_BITS} : an optional flag to indicate whether application binaries are included in archive. Defaults is 'true'.
   {WL_HOME} : an optional parameter for weblogic server location. Required only when the WebLogic Server from 10.3.6 release is installed under a directory other 
               than {ORACLE_HOME}/wlserver_10.3
  
  Example 1:
    exportDomainForPartition.cmd C:\\Oracle_Home C:\\Oracle_Home\\user_projects\\domains\\base_domain
  Example 2:
    exportDomainForPartition.cmd C:\\Oracle_Home C:\\Oracle_Home\\user_projects\\domains\\base_domain myKeyfile
  Example 3: Specifies the location of the com.oracle.weblogic.management.tools.migration.jar file
    exportDomainForPartition.cmd C:\\Oracle_Home C:\\Oracle_Home\\user_projects\\domains\\base_domain myKeyfile C:\\com.oracle.weblogic.management.tools.migration.jar
  Example 4: Only archives the myapp1 and myapp2 applications, and None for KeyFile
    exportDomainForPartition.cmd C:\\Oracle_Home C:\\Oracle_Home\\user_projects\\domains\\base_domain myKeyfile C:\\com.oracle.weblogic.management.tools.migration.jar [myapp1+myapp2] true
Note:
  use \\ as path separator

b) Run the script export-domain.sh/cmd on the host where the source WebLogic domain AdminServer resides.

Command usage:
  export-domain.sh -oh {ORACLE_HOME} -domainDir {WL_DOMAIN_HOME} [-keyFile {KEYFILE}] [-toolJarFile {TOOL_JAR}] [-appNames {APP_NAMES}] [-includeAppBits {INCLUDE_APP_BITS}] [-wlh {WL_HOME}]

  where:
      {ORACLE_HOME} : the MW_HOME of where the WebLogic is installed
      {WL_DOMAIN_HOME} : the source WebLogic domain path
      {KEYFILE} : an optional user-provided file containing a clear-text passphrase used to encrypt exported attributes written to the archive, default: None;
      {TOOL_JAR} : file path to the com.oracle.weblogic.management.tools.migration.jar file. Optional if jar is in the same directory location as the export-domain.sh
      {APP_NAMES} : applicationNames is an optional list of application names to export. E.q:  [\'app1\',\'app2\']. By default, all applications in the domain are exported.
      {INCLUDE_APP_BITS} : an optional flag to indicate whether application binaries are included in archive. Defaults is 'true'.
      {WL_HOME} : an optional parameter for weblogic server location.Used only when the WebLogic Server from 10.3.6 release is installed under a directory other than {ORACLE_HOME}/wlserver_10.3

  Example 1:
    export-domain.sh -oh /Oracle_Home -domainDir /Oracle_Home/user_projects/domains/base_domain
  Example 2:
    export-domain.sh -oh /Oracle_Home -domainDir /Oracle_Home/user_projects/domains/base_domain -keyFile /usr/myUserKeyFile
  Example 3: Specifies the location of the com.oracle.weblogic.management.tools.migration.jar file
    export-domain.sh -oh /Oracle_Home -domainDir /Oracle_Home/user_projects/domains/base_domain -keyFile /usr/myUserKeyFile -toolJarFile /download/com.oracle.weblogic.management.tools.migration.jar
  Example 4: Only archives the 'myapp1' and 'myapp2' applications, and None for KeyFile
    export-domain.sh -oh /Oracle_Home -domainDir /Oracle_Home/user_projects/domains/base_domain -keyFile None -toolJarFile com.oracle.weblogic.management.tools.migration.jar -appNames [\'myapp1\',\'myapp2\'] -includeAppBits true

  For example,
      bash-3.2$  export JAVA_HOME=/opt/jdk1.8.0
      bash-3.2$  ./export-domain.sh -oh /usr/mwhome1036  -domainDir /usr/mwhome1036/user_projects/domains/base_domain -keyFile keyFile -toolJarFile com.oracle.weblogic.management.tools.migration.jar


  The domain archive output of the export-domain is written to a new sub-directory: "outDir".
  For example,
      outDir/base_domain.zip
      outDir/base_domain-attributes.json
      outDir/base_domain-ExportLogReport.html
      outDir/exportDomain.out

Command usage in Windows:

       C:\> set JAVA_HOME=C:\jdk1.8.0 
       C:\> export-domain.cmd -oh C:\\Oracle_Home -domainDir C:\\Oracle_Home\\user_projects\\domains\\base_domain

   Usage: export-domain.cmd -oh {ORACLE_HOME} -domainDir {WL_DOMAIN_HOME} [-keyFile {KEYFILE}] [-toolJarFile {TOOL_JAR}] [-appNames {APP_NAMES}] [-includeAppBits {INCLUDE_APP_BITS}] [-wlh {WL_HOME}]

  Example 1:
    export-domain.cmd -oh C:\\Oracle_Home -domainDir C:\\Oracle_Home\\user_projects\\domains\\base_domain
  Example 2:
    export-domain.cmd -oh C:\\Oracle_Home -domainDir C:\\Oracle_Home\\user_projects\\domains\\base_domain -keyFile myKeyfile -toolJarFile C:\\com.oracle.weblogic.management.tools.migration.jar
            
  Note: use \\ as path separator

  The command line options along with their values can be specified in any order.
  
   For example, 
   ./export-domain.cmd -domainDir C:\\Oracle_Home\\user_projects\\domains\\base_domain -oh C:\\Oracle_Home -appNames [\'chat\']

4. Using the JSON file to override defaults during import
---------------------------------------------------------
As part of the export, a JSON text file is written, both to the archive and as a separate file that you may choose to edit and modify. It specifies some defaults for the partition that will be created during import. 
For example, a default virtual target name is supplied, but you may choose to create a virtual target with a different name. If so, you should edit the JSON file to specify that new name in the "virtual-target" section. 
All the editable fields defined in the JSON file are described below.

A sample JSON file produce by the import tool is shown below. This illustrates both the JSON file objects and attributes, and how they can be overridden:

{
    "virtual-target": [{
        "name": "${PARTITION_NAME}-AdminServer-virtualTarget",
        "target": "AdminServer",
        "uri-prefix": "/${PARTITION_NAME}"
    }],
    "resource-group": [{
        "name": "${PARTITION_NAME}-AdminServer-RG",
        "target": [{
            "virtual-target": {
                "name": "${PARTITION_NAME}-AdminServer-virtualTarget"
            }
        }],
        "app-deployment": [{
            "name": "sampleStandaloneApplication1",
            "exclude-from-import": "false",
			"sub-module-targets": [
                {
                    "name": "sampleAppSubdeployment1",
                    "targets": "__EXISTING_VALUE__"
                }
            ]
        },
		{
            "name": "sampleJMSApplication1",
            "exclude-from-import": "false",
             "jms-modules": [
                {
                    name": "sampleAppJmsModule1",
                    "sub-module-targets": [
                        {
                            "name": "sampleAppJmsModuleSubdeployment1",
                            "targets": "__EXISTING_VALUE__"
                        }
                    ]
                },
                {
                    "name": "sampleAppJmsModule2",
                    "sub-module-targets": [
                        {
                            "name": "sampleAppJmsModuleSubdeployment2",
                            "targets": "__EXISTING_VALUE__"
                        }
                    ]
                }
            ]
        }],
		"library": [{
            "name": "sampleCustomLibrary1",
            "exclude-from-import": "false"
        },
        {
            "name": "sampleSharedLibrary1",
            "exclude-from-import": "false",
            "source-path": "${WL_HOME}\/common\/deployable-libraries\/sampleSharedLibrary1.war",
            "require-exact-version": "false"
        }],
        "file-store": [{
            "name": "sampleFileStore1",
            "exclude-from-import": "false"
        },
        {
            "name": "sampleFileStore2",
            "exclude-from-import": "false"
        }],
        "jms-server": [{
            "name": "sampleJMSServer1",
            "exclude-from-import": "false"
        },
        {
            "name": "sampleJMSServer2",
            "exclude-from-import": "false"
        }],
		"jdbc-system-resource": [{
                "name": "SampleDataSourceXA",
                "exclude-from-import": "false"
         }],
        "jms-system-resource": [{
            "name": "sampleJMSModule1",
            "exclude-from-import": "false",
            "sub-deployment": [{
                "name": "sampleSubDeployment1",
                "exclude-from-import": "false"
            }]
        },
        {
            "name": "sampleJMSModule2",
            "exclude-from-import": "false",
            "sub-deployment": [{
                "name": "sampleSubDeployment2",
                "exclude-from-import": "false"
            }]
        }],
        "resource-group-template": {
            "name": "${PARTITION_NAME}-AdminServer-RGTemplate"
        }
    }],
    "partition": {
        "default-target": [{
            "virtual-target": {
                "name": "${PARTITION_NAME}-AdminServer-virtualTarget"
            }
        }],
        "jdbc-system-resource-override": [{
            "name": "SampleDataSourceXA",
            "url": "__EXISTING_VALUE__",
            "user": "__EXISTING_VALUE__",
            "password-encrypted": "__EXISTING_VALUE__"
        }],
        "jms-system-resource-override": [{
            "name": "sampleJMSModule1",
            "foreign-server-override": [{
                "name": "ForeignServer1",
                "foreign-destination-override": [{
                    "name": "ForeignDestination1",
                    "remote-jndi-name": "__EXISTING_VALUE__"
                },
                {
                    "name": "ForeignDestination2",
                    "remote-jndi-name": "__EXISTING_VALUE__"
                }],
                "foreign-connection-factory-override": [{
                    "name": "ForeignConnectionFactory1",
                    "remote-jndi-name": "__EXISTING_VALUE__",
                    "username": "__EXISTING_VALUE__"
                }]
            }]
        }],
        "realm": "__EXISTING_VALUE__",
        "available-target": [{
            "virtual-target": {
                "name": "${PARTITION_NAME}-AdminServer-virtualTarget"
            }
        }]
    },
    "implementation-version": "12.2.1.2"
}

The objects "virtual-target", "resource-group", "resource-group-template" and "partition" represent Virtual Target, Resource Group, Resource Group Template 
and Domain Partition respectively, as documented in Multitenancy Support in WebLogic.

Root level object "virtual-target" :
   The import tool will conveniently create virtual targets listed in the json, although it uses if the Virtual Targets are already configured.
   Remove this object and/or any values to skip the creation of virtual target(s) during import.

Object "resource-group" :
   The tool creates one resource group per WebLogic Server(which is not part of the Cluster) or Cluster.

Object "partition" :
   Contains elements and values required for creation of the partition.
   If you have pre-created virtual target(s) for this partition, replace the "virtual-target" value (within "default-target" and "available-target") with the proper 
   existing virtual target(s).
   
Attribute "exclude-from-import" :
   This is the attribute to tell importer to whether to exclude this Object. See the "Limitations" section, below, for restrictions on JMS resource targeting in partitions.
   Set value to "true" to exclude. The default value is "false".

Where the optional system replaceable attribute values are:
      ${PARTITION_NAME}  : to be replaced at import by command argument partitionName

      ${WL_HOME} : to be replaced by the WebLogic Server home path of which the target domain uses

      __EXISTING_VALUE__ : For users/customers to re-write this value.
                           Otherwise, at import the value is taken either from the target domain default, source configuration, or target configuration existing data.

Please note that, the "name" attribute in the JSON file can be modified only for virtual-target, resource-group and resource-group-template. Please do not change the name 
attribute of other objects in the JSON file.

The JSON object jdbc-store in the JSON file represents a JDBC Store, and by default the tool sets "__EXISTING_VALUE__" for the attribute prefix-name. As the JDBC Store tries to
create the table used by the store in the database, before import it is expected that a new prefix is set for the attribute prefix-name in the JSON file.

5. How to import a domain archive to a WebLogic 12.2.1 (or later) Partition
----------------------------------------------------------------------------
These are the steps to import the domain archive to WebLogic 12.2.1 or later, and creating a new partition:
 . Start the target WebLogic domain Admin Server.
     $ ./startWebLogic.sh
 . Invoke the WebLogic WLST command to import the domain archive. The command needs to be executed in on-line mode.
 . In the target domain, connect to WebLogic domain AdminServer using WLST
   e.q.:
     wlst> connect('user', 'mypassword', 't3://myserver:7001')

 . Execute the WLST command (replacing the parameter names with the appropriate values):
     importPartition( archiveFileName , partitionName , createRGT , userKeyFile )

   e.q.:
     wls:/wsDomain/> importPartition( '/outDirbase_domain.zip', 'testPartition',  true,  '/usr/myUserKeyFile' )

   where:
     archiveFileName : Full path to the archive file to import as seen by the 12.2.1 WLS admin server (not the client).
                      The command will also look for a file, <domain name>-attributes.json, in the same directory as the specified domain archive file.
                      If it is found, then the values in that file will override those in the archive.
     partitionName : name of the partition to be created for migration.
     createRGT : A flag to whether to create a Resource Group Template (RGT) for all the resources in the archive, and used by the new partition.
                 True: to create a RGT. False: all resources will be added directly to the new partition's Resource Group.
     userKeyFile : a user-provided file containing the same clear-text passphrase specified during export; used to decrypt attributes in the archive;


6. Limitations
--------------
6.1 The target domain must be a 12.2.1 (or later) domain. Prior to using import to create a new partition, any required Servers, Clusters, Security Realms must have previously been created.
6.2 The tool supports migrating a WLS 12.2.1 domain to a WLS 12.2.1 (or later) partition, any pre-existing Resource Groups and Resource Group Templates in the source domain are ignored.
6.3 The domain upgrade of libraries and/or resources to a new release is not supported by the import tool. Admin/users will be responsible for possible necessary domain upgrade from source domain before export to archive.
6.4 No application runtime state, nor application specific runtime configuration is exported to the archive. For example JMS messages in queues and users in an embedded LDAP realm are not exported.
6.5 When there are multiple JMS servers targeted to multiple Migratable targets, where all the multiple targets are associated to the same cluster, only one JMS server would be created with an effective target of a cluster. 
    The other JMS Servers would be ignored. If any of the subdeployments in any of the JMS System modules had referred to these ignored JMS servers, the subdeployment would be untargeted and all the destinations which refer the subdeployment will not be deployed.
6.6 For those old remote clients compiled with WLS versions earlier than 12.2.1, it would not be able to do the lookup to a JNDI resource deployed on a partition. They need to be recompiled with the WLS versions 12.2.1 or above.
6.7 The applications and resources targeted to more than one WebLogic Servers and/or Clusters are skipped during the export with a warning.
6.8 When a JMS Server hosting the standalone destination (queue or topic) and a SAF Agent share the same persistence store, the import of the domain archive will fail with an exception indicating the reason for the failure. 
    In a domain partition, a JMS Server can host the standalone destination only when it references a persistence store with distribution policy 'Singleton'. However a SAF agent can only reference a persistence store with distribution policy 'Distributed'. 
    So when D-PCT finds this conflicting configuration, it fails with an exception.
6.9 All default targeted Uniform Distributed Destinations and SAF Imported Destinations in a JMS system module, would be left untargeted. After import, the user has to target these resource manually using the subdeployment targeting.

For additional details, please refer the chapter "Migrating a WebLogic Server Domain to a Domain Partition" in the documentation - Oracle� Fusion Middleware Using WebLogic Server Multitenant and the release notes.
