#!/bin/bash

# Copyright (c) 2015,2018 Oracle and/or its affiliates. All rights reserved.
# For exporting a WebLogic domain to an archive for migration/importing to a partition
#
usage(){
   echo " Example 1:"
   echo "   export-domain.sh -oh /Oracle_Home -domainDir /Oracle_Home/user_projects/domains/base_domain "
   echo " Example 2:"
   echo "   export-domain.sh -oh /Oracle_Home -domainDir /Oracle_Home/user_projects/domains/base_domain -keyFile /usr/myUserKeyFile "
   echo " Example 3: Specifies the location of the com.oracle.weblogic.management.tools.migration.jar file "
   echo "   export-domain.sh -oh /Oracle_Home -domainDir /Oracle_Home/user_projects/domains/base_domain -keyFile /usr/myUserKeyFile -toolJarFile /download/com.oracle.weblogic.management.tools.migration.jar "
   echo " Example 4: Only archives the 'myapp1' and 'myapp2' applications, and None for KeyFile "
   echo "   export-domain.sh -oh /Oracle_Home -domainDir /Oracle_Home/user_projects/domains/base_domain -keyFile None -toolJarFile com.oracle.weblogic.management.tools.migration.jar -appNames [\'myapp1\',\'myapp2\'] -includeAppBits true "
}
syntax(){
   echo "Usage: export-domain.sh -oh {ORACLE_HOME} -domainDir {WL_DOMAIN_HOME}" 
   echo "       [-keyFile {KEYFILE}] [-toolJarFile {TOOL_JAR}] [-appNames {APP_NAMES}]"
   echo "		[-includeAppBits {INCLUDE_APP_BITS}] [-wlh {WL_HOME}]"
   echo "       where:"
   echo "             {ORACLE_HOME} : the MW_HOME of where the WebLogic is installed"
   echo "             {WL_DOMAIN_HOME} : the source WebLogic domain path"
   echo "             {KEYFILE} : an optional user-provided file containing a clear-text" 
   echo "             passphrase used to encrypt exported attributes written to the archive, default: None;"
   echo "             {TOOL_JAR} : file path to the com.oracle.weblogic.management.tools.migration.jar file."
   echo "             Optional if jar is in the same directory location as the export-domain.sh"
   echo "             {APP_NAMES} : applicationNames is an optional list of application names to export."
   echo "             {WL_HOME} : an optional parameter giving the path of the weblogic server for version 10.3.6.Used only when the WebLogic Server from 10.3.6 release is         installed under a directory other than {ORACLE_HOME}/wlserver_10.3"
   echo "             Run "export-domain.sh -help" to see usage examples"
}
if [ "$1" == "-help" ] ; then
    syntax `basename $0`
	echo " "
	usage `basename $0`
	exit 1
fi 
if [ $# -lt 4 ] ; then
   syntax `basename $0`   
   exit 1
fi

ORACLE_HOME=None
WL_DOMAIN_HOME=None
KEYFILE=None
TOOL_JAR=`pwd`/com.oracle.weblogic.management.tools.migration.jar
BINHOME=.
APP_NAMES=None
INCLUDE_APP_BITS=None
TEMP_ORA_HOME=${ORACLE_HOME}
WL_HOME=None
MW_HOME=None
IMPLEMENTATION_VERSION=12.2.1.4
EQUALSET=0
CURRENT=None
KEY=None
for arg in $* ; do
   hasOraHome=`echo $arg | grep -- "-oh" | wc -l`
   hasWLDomainHome=`echo $arg | grep -- "-domainDir" | wc -l`
   hasKeyFile=`echo $arg | grep -- "-keyFile" | wc -l`
   hasToolJar=`echo $arg | grep -- "-toolJarFile" | wc -l`
   hasApps=`echo $arg | grep -- "-appNames" | wc -l`
   hasAppBits=`echo $arg | grep -- "-includeAppBits" | wc -l`
   hasWLHome=`echo $arg | grep -- "-wlh" | wc -l`
   CURRENT=None
   if [ $hasOraHome -eq 1 -o $hasWLDomainHome -eq 1 -o $hasKeyFile -eq 1 -o $hasToolJar -eq 1 -o $hasApps -eq 1 -o $hasAppBits -eq 1 -o $hasWLHome -eq 1 ] ; then
		KEY=$arg
		CURRENT=$arg
   fi
   if [ "None" == "${CURRENT}" ] ; then
		if [ "-oh" == "${KEY}" ] ; then
			ORACLE_HOME=$arg
			TEMP_ORA_HOME=${ORACLE_HOME}
			KEY=None
		fi
		if [ "-domainDir" == "${KEY}" ] ; then
			WL_DOMAIN_HOME=$arg
			KEY=None
		fi
		if [ "-keyFile" == "${KEY}" ] ; then
		    TEMP_KEY=${arg//%%}
			KEYFILE=\"$TEMPKEY\"
			KEY=None
		fi
		if [ "-toolJarFile" == "${KEY}" ] ; then
			TOOL_JAR=$arg
			KEY=None
		fi
		if [ "-appNames" == "${KEY}" ] ; then
			TEMP_APP=${arg//%%}
			APP_NAMES=\"$TEMP_APP\"
			KEY=None
		fi
		if [ "-includeAppBits" == "${KEY}" ] ; then
			INCLUDE_APP_BITS=$arg
			KEY=None
		fi
		if [ "-wlh" == "${KEY}" ] ; then
			WL_HOME=$arg
			KEY=None
		fi
   fi
done
if [ "None" == "${ORACLE_HOME}" ] ; then
    echo "Oracle Home is mandatory."
	exit 1
fi
if [ "None" == "${WL_DOMAIN_HOME}" ] ; then
    echo "Weblogic Domain path is mandatory."
	exit 1
fi
if [ ! -e $WL_DOMAIN_HOME ] ; then
    echo "The WebLogic domain path does not exist!"
    echo "Please provide a proper WebLogic domain path."
    exit 1
fi

if [ -e $ORACLE_HOME/oracle_common/common/bin/wlst.sh ] ; then
   BINHOME=$ORACLE_HOME/oracle_common/common/bin
fi

if [ "." == "${BINHOME}" ] ; then
   if [ -e $ORACLE_HOME/wlserver_10.3/common/bin/wlst.sh ] ; then
      BINHOME=$ORACLE_HOME/wlserver_10.3/common/bin
   elif [ "None" != "${WL_HOME}" ] ; then
      BINHOME=${WL_HOME}/common/bin
	  MW_HOME=${ORACLE_HOME}
   else
      echo "The Oracle home WLST bin path is not found" 
   fi
   export JAVA_VENDOR="Oracle"
   if [ -z "${JAVA_HOME}" ] ; then
      echo " "
      echo "Please note: the classes in com.oracle.weblogic.management.tools.migration.jar are built with JDK8 and must be run with JDK8.  Set your JAVA_HOME to a JDK8 installation before running the export script."
      echo " "
   fi
fi

if [ "." == "${BINHOME}" ] ; then
    echo "The Oracle home WLST bin path is not found at "${ORACLE_HOME}
    echo "Please assure to run this export at the AdminServer."
    exit 1
fi

if [ "com.oracle.weblogic.management.tools.migration.jar" == $TOOL_JAR ] ; then
   TOOL_JAR=`pwd`/com.oracle.weblogic.management.tools.migration.jar
fi

if [ ! -e $TOOL_JAR ] ; then
   echo "Could not locate com.oracle.weblogic.management.tools.migration.jar file!"
   echo "Usage: export-domain.sh -oh {ORACLE_HOME} -domainDir {WL_DOMAIN_HOME} [-keyFile {KEYFILE}] [-toolJarFile {TOOL_JAR}] [-appNames {APP_NAMES}] [-includeAppBits {INCLUDE_APP_BITS}] [-wlh {WL_HOME}]"
   exit 1
fi

if [ -e outDir ] ; then
   rm -rf outDir
fi
mkdir outDir

if [ -e tmpwlst ] ; then
   rm -rf tmpwlst
fi
mkdir tmpwlst

if [ -e lifttmp ] ; then
   rm -rf lifttmp
fi
mkdir lifttmp

cd lifttmp
jar -xf $TOOL_JAR
cd ..
cp lifttmp/wlstScriptDir/*.py  tmpwlst/.
rm -rf lifttmp

echo "print \"WLST homepath:\"" >> runExport.py
echo "print System.getProperty(\"weblogic.wlstHome\") " >> runExport.py
echo "print sys.path" >> runExport.py
echo "exportForMigration('./outDir', '${WL_DOMAIN_HOME}', ${INCLUDE_APP_BITS}, ${KEYFILE}, ${APP_NAMES}, '${IMPLEMENTATION_VERSION}' ) " >> runExport.py
echo "exit() " >> runExport.py
EXT_PRE_CLASSPATH="${TOOL_JAR}${CLASSPATHSEP}${EXT_PRE_CLASSPATH}"
export EXT_PRE_CLASSPATH
WLST_EXT_CLASSPATH="${TOOL_JAR}${CLASSPATHSEP}${WLST_EXT_CLASSPATH}"
export WLST_EXT_CLASSPATH
PRE_CLASSPATH=${PRE_CLASSPATH}${CLASSPATHSEP}${TEMP_ORA_HOME}/modules/jettison_1.0.0.0_1-1.jar
export PRE_CLASSPATH
export WLST_HOME="`pwd`/tmpwlst"
export MW_HOME
${BINHOME}/wlst.sh runExport.py>`pwd`/outDir/exportDomain.out


rm -rf tmpwlst
rm runExport.py

echo "Export Weblogic domain completed to outDir."
ls -l ./outDir
echo "Please check the exportDomain.out file in the directory outDir for any errors/warnings reported during export, before proceeding further."
